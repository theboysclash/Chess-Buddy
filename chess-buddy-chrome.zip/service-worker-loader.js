import './assets/service-worker.ts-DnqxEbQC.js';
